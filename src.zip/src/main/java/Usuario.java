public class Usuario {

    String nome;
    int idade;
    String cpf;
    String endereço;
    String telefone;
    Conta user= new Conta();

    void cadastro()
    {
        nome=nome;
        idade=idade;
        cpf=cpf;
        endereço=endereço;
        telefone=telefone;

        System.out.println("Usuário Cadastrado com sucesso");

    }
}
